package com.example.truequelibre;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class QueOfrecesACambio extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_que_ofreces_acambio);
    }
}